//
// Created by Firef on 15.05.2022.
//

#ifndef TESTO_KEYVALSORE_H
#define TESTO_KEYVALSORE_H
#include <string.h>
typedef struct Store{
    char tkey[50];
    char tvalue[50];
}Store_;

int put(char[], char[], Store_[],int);
int get(char[],Store_ [],int );
int del(char[],Store_ [],int);


#endif //TESTO_KEYVALSORE_H
