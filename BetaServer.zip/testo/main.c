#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

#include "KeyValSore.h"
#include "sub.h"

#define BUFSIZE 1024 // Größe des Buffers
#define ENDLOSSCHLEIFE 1
#define PORT 5678


int main() {
    int wahl, Ergebnis, anzahl = 1;
    char KEY[50], Value[50];
    Store_ *p;
    int i = 0;

    int rfd; // Rendevouz-Descriptor
    int cfd; // Verbindungs-Descriptor

    struct sockaddr_in client; // Socketadresse eines Clients
    socklen_t client_len; // Länge der Client-Daten
    char in[BUFSIZE]; // Daten vom Client an den Server
    char out[BUFSIZE];//Daten vom Server an den Client
    int bytes_read; // Anzahl der Bytes, die der Client geschickt hat

//unterteilen
    char delimiter[] = ";";
    char *EingabeClient;
    char *Wort[50];

     //erstellen
    //getMyIP(ownIP_Addr);
    printf("Programm wurde gestartet (pid=%d)\n",getpid());

    // Socket erstellen
    rfd = socket(AF_INET, SOCK_STREAM, 0);
    if (rfd < 0) {
        fprintf(stderr, "socket konnte nicht erstellt werden\n");
        exit(-1);
    }


    // Socket Optionen setzen für schnelles wiederholtes Binden der Adresse
    int option = 1;
    setsockopt(rfd, SOL_SOCKET, SO_REUSEADDR, (const void *) &option, sizeof(int));


    // Socket binden
    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(PORT);
    int brt = bind(rfd, (struct sockaddr *) &server, sizeof(server));
    if (brt < 0) {
        fprintf(stderr, "socket konnte nicht gebunden werden\n");
        exit(-1);
    }


    // Socket lauschen lassen
    int lrt = listen(rfd, 5);
    if (lrt < 0) {
        fprintf(stderr, "socket konnte nicht listen gesetzt werden\n");
        exit(-1);
    }
    while (ENDLOSSCHLEIFE) {
        // Verbindung eines Clients wird entgegengenommen
        cfd = accept(rfd, (struct sockaddr *) &client, &client_len);

        while (strcmp(Wort[0], "QUIT") != 0) {

            // Lesen von Daten, die der Client schickt
            bytes_read = read(cfd, in, BUFSIZE);
            //Array unterteilen
            EingabeClient = strtok(in, delimiter);

            while (EingabeClient != NULL) {
                Wort[i++] = EingabeClient;
                printf("Abschnitt gefunden: %s\n", EingabeClient);
                // naechsten Abschnitt erstellen
                EingabeClient = strtok(NULL, delimiter);

            }
            //Text mit Methoden abgleichen
            if (strcmp(Wort[0], "PUT") == 0) {
                Ergebnis = put(Wort[1], Wort[2], &p, anzahl);
                if (Ergebnis < 0) {
                    printf("Der Key wurde hinzugefügt");
                    strcpy(out, "Der Key wurde hinzugefügt");
                    write(cfd, out, bytes_read);
                    anzahl++;
                } else {
                    printf("Der Key konnte nicht hinzugefügt werden");
                    strcpy(out, "Der Key konnte nicht hinzugefügt werden");
                    write(cfd, out, bytes_read);
                }
            } else if (strcmp(Wort[0], "GET") == 0) {
                Ergebnis = get(Wort[1], &p, anzahl);
                if (Ergebnis < 0) {
                    printf("Der Key wurde nicht gefunden");
                    strcpy(out, "Der Key wurde nicht gefunden");
                    write(cfd, out, bytes_read);
                } else {
                    printf("Der Value von %s ist %s", p[Ergebnis].tkey, p[Ergebnis].tvalue);
                    strcpy(out, ("Der Value von %s ist %s", p[Ergebnis].tkey, p[Ergebnis].tvalue));
                    write(cfd, out, bytes_read);
                }
            }else if (strcmp(Wort[0], "DEL") == 0) {
                Ergebnis = del(Wort[1], &p, anzahl);
                if (Ergebnis < 0) {
                    printf("Der Key wurde nicht gefunden");
                    strcpy(out, "Der Key wurde nicht gefunden");
                    write(cfd, out, bytes_read);
                } else {
                    printf("Der Key wurde gelöscht");
                    strcpy(out, "Der Key wurde gelöscht");
                    write(cfd, out, bytes_read);
                    anzahl--;
                }
            }else if (strcmp(Wort[0], "QUIT") == 0) {

                    close(cfd);
                }/*else{
                // Zurückschicken der Daten an den Client
                while (bytes_read > 0) {
                    printf("sending back the %d bytes I received...\n", bytes_read);

                    write(cfd, in, bytes_read);
                    bytes_read = read(cfd, in, BUFSIZE);

                }*/
            }
                close(cfd);
            }
            // Rendevouz Descriptor schließen
            close(rfd);

        }


