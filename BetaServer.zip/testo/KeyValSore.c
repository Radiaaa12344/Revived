//
// Created by Firef on 15.05.2022.
//

#include "KeyValSore.h"

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int put(char * key, char * value,Store_ * p, int anzahl){
    int N;
    //Die put() Funktion soll eine Wert (value) mit dem Schlüsselwert (key) hinterlegen. Wenn der Schlüssel bereits
    // vorhanden ist, soll der Wert überschrieben werden. Der Rückgabewert der Funktion könnte Auskunft dazu geben.
    p = (Store_*)realloc(p, anzahl*sizeof(Store_));
    if(p != NULL)
        printf("\nSpeicher ist reserviert\n");
    else
        printf("\nKein freier Speicher vorhanden.\n");

    N=get(key, &p,anzahl);
    if(N<0) {
        strcpy(p[anzahl - 1].tkey, key);
        strcpy(p[anzahl - 1].tvalue, value);
    }
    return N;
}

int get(char * key,Store_ * p,int anzahl){
    int i=0;
    for(i;i<anzahl;i++) {
        if (strcmp(key,p[i].tkey) == 0)
            return i;
    }
    return -1;}

//Die get() Funktion soll einen Schlüsselwert (key) in der Datenhaltung suchen und den hinterlegten Wert (value)
// zurückgeben. Ist der Wert nicht vorhanden, wird durch einen Rückgabewert <0 darauf aufmerksam gemacht.



int del(char * key,Store_ *p,int anzahl){
    int i,n=get(key, &p,anzahl);
    if(n>=0){
        i=n;
        do {
            strcpy(p[i].tkey, p[anzahl+1 ].tkey);
            strcpy(p[i].tvalue, p[anzahl +1].tvalue);
            i++;
        }while(i<=anzahl);
        strcpy(p[i].tvalue,"");
        strcpy(p[i].tkey,"");
    }
    else
    {}
    //Die del() Funktion soll einen Schlüsselwert suchen und zusammen mit dem Wert aus der Datenhaltung entfernen.
    return n;
}